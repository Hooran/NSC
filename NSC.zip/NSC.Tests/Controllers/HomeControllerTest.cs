﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSC.Controllers;
using NSC.Models;
using NSC.Services;
using System.Web.Mvc;

namespace NSC.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        protected SequenceService sequenceService = new SequenceService();

        [TestMethod]
        public void InvalidInput()
        {
            //Setup
            HomeModel modelActual = new HomeModel()
            {
                Number = 0
            };

            // Act
            HomeController controller = new HomeController();
            ViewResult result = controller.Index(modelActual) as ViewResult;
            HomeModel modelResult = result.Model as HomeModel;

            // Assert
            Assert.AreEqual(modelResult.EvenSequence, string.Empty);
            Assert.AreEqual(modelResult.OddSequence, string.Empty);
            Assert.AreEqual(modelResult.CharSequence, string.Empty);
        }

        [TestMethod]
        public void ValidInput()
        {
            //Setup
            HomeModel modelActual = new HomeModel()
            {
                Number = 20
            };

            // Act
            HomeController controller = new HomeController();
            ViewResult result = controller.Index(modelActual) as ViewResult;
            HomeModel modelResult = result.Model as HomeModel;

            // Assert
            Assert.IsTrue(modelResult.EvenSequence.Length > 0);
            Assert.IsTrue(modelResult.OddSequence.Length > 0);
            Assert.IsTrue(modelResult.CharSequence.Length > 0);
            Assert.IsTrue(modelResult.FibonacciSequence.Length > 0);
        }
    }
}
