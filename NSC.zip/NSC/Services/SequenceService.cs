﻿using System.Collections.Generic;
using System.Text;

namespace NSC.Services
{
    public class SequenceService
    {
        protected List<StringBuilder> stringBuilderList;
        public StringBuilder GetFibonacciSequence(int inputNumber)
        {
            StringBuilder strFibo = new StringBuilder();
            int first = 1;
            int second = 1;
            int current = 2;

            strFibo.Append("0 1 1 ");

            while (current <= inputNumber)
            {
                strFibo.Append(current + " ");

                first = second;
                second = current;

                current = first + second;
            }

            return strFibo;
        }

        public List<StringBuilder> GetSequences(int start, int end)
        {
            stringBuilderList = new List<StringBuilder>();

            for (int i = 0;i < 5;i++)
            {
                stringBuilderList.Add(new StringBuilder());
            }

            for (int i = start; i <= end; i++)
            {
                stringBuilderList[0].Append(i + " ");

                if ((i % 2) != 1) stringBuilderList[1].Append(i.ToString() + " ");
                else stringBuilderList[2].Append(i.ToString() + " ");

                if (i % 3 == 0 && i % 5 == 0) stringBuilderList[3].Append("Z ");
                else if (i % 3 == 0) stringBuilderList[3].Append("C ");
                else if (i % 5 == 0) stringBuilderList[3].Append("E ");
                else stringBuilderList[3].Append(i.ToString() + " ");
            }

            stringBuilderList[4] = GetFibonacciSequence(end);

            return stringBuilderList;
        }
    }
}