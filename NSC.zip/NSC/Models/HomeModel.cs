﻿namespace NSC.Models
{
    public class HomeModel
    {
        public int Number { get; set; }
        public string Sequence { get; set; }
        public string OddSequence { get; set; }
        public string EvenSequence { get; set; }
        public string CharSequence { get; set; }
        public string FibonacciSequence { get; set; }
    }
}