﻿namespace NSC.Framework
{
    public class Enums
    {
        public enum SequenceType
        {
            Normal,
            Even,
            Odd,
            Char,
            Fibonacci
        }
    }
}