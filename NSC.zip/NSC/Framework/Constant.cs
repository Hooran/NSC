﻿namespace NSC.Constants
{
    public class Constant
    {
        public static int MaxNumber = 1000;
        public static int MaxLimit = 10000;
    }
}