﻿angular.module('myApp', [])
    .controller('calculatorController', ['$scope', function ($scope) {
        
        $scope.Calculate = function (event) {

            if ($scope.Number == '' || $scope.Number == null || $scope.Number < 1) {
                event.preventDefault();
                $scope.Message = 'Number must be positive.';
            }
            else {
                $scope.Message = '';
            }
        };
}]);