﻿using NSC.Constants;
using NSC.Models;
using NSC.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Mvc;

namespace NSC.Controllers
{
    public class HomeController : Controller
    {
        protected SequenceService sequenceService = new SequenceService();
        protected List<StringBuilder> stringBuilderList;
        protected int start, end;

        public ActionResult Index()
        {
            HomeModel model = new HomeModel();
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(HomeModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                model = GetSequences(model.Number);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }

            return View(model);
        }

        private HomeModel GetSequences(int number, int loadNumber = 1)
        {
            HomeModel model = new HomeModel() {
                Number = number
            };

            start = 1;
            end = number;
            stringBuilderList = new List<StringBuilder>();

            if (number <= Constant.MaxNumber && loadNumber > 1) return model;
            
            SetValues(number, loadNumber);

            stringBuilderList = sequenceService.GetSequences(start, end);

            PopulateModel(model);

            return model;
        }

        protected void SetValues(int number, int loadNumber)
        {
            start = (Constant.MaxNumber * (loadNumber - 1)) + 1;
            end = (loadNumber) * Constant.MaxNumber;

            if (end > number) end = number;
        }

        protected void PopulateModel(HomeModel model)
        {
            model.Sequence = stringBuilderList[0].ToString();
            model.OddSequence = stringBuilderList[1].ToString();
            model.EvenSequence = stringBuilderList[2].ToString();
            model.CharSequence = stringBuilderList[3].ToString();
            model.FibonacciSequence = stringBuilderList[4].ToString();
        }
    }
}